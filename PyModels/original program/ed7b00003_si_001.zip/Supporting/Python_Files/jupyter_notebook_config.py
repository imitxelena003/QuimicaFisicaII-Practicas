c.NotebookApp.mathjax_url = "https://cdn.mathjax.org/mathjax/latest/MathJax.js"
